// ===== leaderboard.js =====
(() => {
  "use strict";

  const participants = [
    { name: "Arjun Mehta", college: "VIT Chennai", score: 980, solved: 9, penalty: 112 },
    { name: "Sneha Iyer", college: "VIT Chennai", score: 960, solved: 9, penalty: 118 },
    { name: "Karthik R", college: "SRM Institute", score: 945, solved: 8, penalty: 121 },
    { name: "Ananya Shah", college: "IIT Madras", score: 940, solved: 8, penalty: 124 },
    { name: "Vikram Singh", college: "NIT Trichy", score: 935, solved: 8, penalty: 129 },
    { name: "Harini K", college: "VIT Vellore", score: 930, solved: 8, penalty: 132 },
    { name: "Rohit Gupta", college: "Anna University", score: 925, solved: 8, penalty: 136 },
    { name: "Diya Nair", college: "SSN College", score: 920, solved: 8, penalty: 138 },
    { name: "Aditya Rao", college: "VIT Chennai", score: 910, solved: 7, penalty: 140 },
    { name: "Meera Prasad", college: "IIT Madras", score: 905, solved: 7, penalty: 144 },
    { name: "Siddharth Jain", college: "NIT Surathkal", score: 900, solved: 7, penalty: 149 },
    { name: "Nivedita S", college: "SRM Institute", score: 895, solved: 7, penalty: 151 },
    { name: "Rishi Kumar", college: "VIT Vellore", score: 888, solved: 7, penalty: 158 },
    { name: "Ayesha Khan", college: "Anna University", score: 880, solved: 7, penalty: 160 },
    { name: "Sanjay Bose", college: "VIT Chennai", score: 875, solved: 7, penalty: 164 },
    { name: "Lavanya M", college: "SSN College", score: 870, solved: 7, penalty: 167 },
    { name: "Pranav S", college: "IIT Madras", score: 865, solved: 6, penalty: 170 },
    { name: "Ishita Roy", college: "NIT Trichy", score: 860, solved: 6, penalty: 173 },
    { name: "Gokul Narayan", college: "VIT Chennai", score: 855, solved: 6, penalty: 176 },
    { name: "Neha Verma", college: "NIT Surathkal", score: 850, solved: 6, penalty: 179 },
    { name: "Abhishek T", college: "VIT Vellore", score: 845, solved: 6, penalty: 182 },
    { name: "Keerthana P", college: "SRM Institute", score: 840, solved: 6, penalty: 186 },
    { name: "Raghav A", college: "Anna University", score: 835, solved: 6, penalty: 188 },
    { name: "Tanya Kapoor", college: "SSN College", score: 830, solved: 6, penalty: 192 },
    { name: "Manoj S", college: "VIT Chennai", score: 825, solved: 6, penalty: 195 },
    { name: "Sonal Gupta", college: "NIT Trichy", score: 820, solved: 6, penalty: 198 },
    { name: "Rahul N", college: "IIT Madras", score: 815, solved: 5, penalty: 203 },
    { name: "Anish B", college: "VIT Vellore", score: 810, solved: 5, penalty: 206 },
    { name: "Pooja S", college: "SRM Institute", score: 805, solved: 5, penalty: 210 },
    { name: "Varun K", college: "Anna University", score: 800, solved: 5, penalty: 214 },
    { name: "Divya R", college: "SSN College", score: 795, solved: 5, penalty: 218 },
    { name: "Shreya I", college: "NIT Surathkal", score: 790, solved: 5, penalty: 222 },
    { name: "Kiran M", college: "VIT Chennai", score: 785, solved: 5, penalty: 226 },
    { name: "Suresh V", college: "NIT Trichy", score: 780, solved: 5, penalty: 231 },
  ];

  const elList = document.getElementById("lbList");
  const elSkeleton = document.getElementById("lbSkeleton");
  const elPodium = document.getElementById("podium");

  const elSearch = document.getElementById("searchName");
  const elCollege = document.getElementById("collegeFilter");
  const elSort = document.getElementById("sortBy");
  const elReset = document.getElementById("resetFilters");

  const elEmpty = document.getElementById("emptyState");
  const countParticipants = document.getElementById("countParticipants");
  const countColleges = document.getElementById("countColleges");

  if (!elList || !elSkeleton || !elPodium || !elSearch || !elCollege || !elSort || !elReset) {
    return;
  }

  // Skeleton
  const makeSkeleton = (n = 8) => {
    elSkeleton.innerHTML = "";
    for (let i = 0; i < n; i++) {
      const d = document.createElement("div");
      d.className = "skel-row";
      elSkeleton.appendChild(d);
    }
  };

  const uniqueColleges = () => {
    const set = new Set(participants.map((p) => p.college));
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  };

  const fillCollegeDropdown = () => {
    const colleges = uniqueColleges();
    // Clear existing except first
    while (elCollege.options.length > 1) elCollege.remove(1);
    colleges.forEach((c) => {
      const opt = document.createElement("option");
      opt.value = c;
      opt.textContent = c;
      elCollege.appendChild(opt);
    });

    if (countColleges) countColleges.textContent = String(colleges.length);
  };

  const getFiltered = () => {
    const q = String(elSearch.value || "").trim().toLowerCase();
    const college = elCollege.value;
    const sortBy = elSort.value;

    let data = participants.slice();

    if (q) {
      data = data.filter((p) => p.name.toLowerCase().includes(q));
    }
    if (college && college !== "all") {
      data = data.filter((p) => p.college === college);
    }

    // Sort
    data.sort((a, b) => {
      if (sortBy === "score_desc") return b.score - a.score || a.penalty - b.penalty;
      if (sortBy === "score_asc") return a.score - b.score || a.penalty - b.penalty;
      if (sortBy === "penalty_asc") return a.penalty - b.penalty || b.score - a.score;
      if (sortBy === "penalty_desc") return b.penalty - a.penalty || b.score - a.score;
      return b.score - a.score || a.penalty - b.penalty;
    });

    return data;
  };

  const renderPodium = (sorted) => {
    const top3 = sorted.slice(0, 3);
    elPodium.innerHTML = "";

    const card = (p, rankLabel, cls, badge) => {
      const div = document.createElement("div");
      div.className = `podium-card ${cls}`;

      div.innerHTML = `
        <div class="podium-rank">
          <strong>${rankLabel}</strong>
          <span class="podium-badge">${badge}</span>
        </div>
        <h3 class="podium-name">${escapeHTML(p.name)}</h3>
        <div class="podium-meta">
          <span>${escapeHTML(p.college)}</span>
          <span>Solved: ${p.solved}</span>
        </div>
        <div class="podium-meta" style="margin-top:6px;">
          <span class="cell-muted">Penalty: ${p.penalty}</span>
          <span class="cell-muted">Score</span>
        </div>
        <div class="podium-score">${p.score}</div>
      `;
      return div;
    };

    // Nice layout order: 2nd, 1st, 3rd
    if (top3[1]) elPodium.appendChild(card(top3[1], "Rank #2", "second", "Silver"));
    if (top3[0]) elPodium.appendChild(card(top3[0], "Rank #1", "first", "Champion"));
    if (top3[2]) elPodium.appendChild(card(top3[2], "Rank #3", "third", "Bronze"));
  };

  const renderRows = (sorted) => {
    elList.innerHTML = "";

    if (countParticipants) countParticipants.textContent = String(sorted.length);

    if (!sorted.length) {
      elEmpty.hidden = false;
      return;
    }
    elEmpty.hidden = true;

    sorted.forEach((p, idx) => {
      const rank = idx + 1;

      const row = document.createElement("div");
      row.className = "row";
      row.setAttribute("role", "row");

      row.innerHTML = `
        <div class="cell-strong" role="cell">
          <span class="rank-pill">#${rank}</span>
        </div>
        <div role="cell">
          <div class="cell-strong">${escapeHTML(p.name)}</div>
          <div class="cell-muted" style="margin-top:4px;">Participant</div>
        </div>
        <div role="cell">
          <div class="cell-strong">${escapeHTML(p.college)}</div>
          <div class="cell-muted" style="margin-top:4px;">College</div>
        </div>
        <div class="right" role="cell">
          <div class="cell-strong">${p.score}</div>
          <div class="cell-muted" style="margin-top:4px;">Score</div>
        </div>
        <div class="right" role="cell">
          <div class="cell-strong">${p.solved}</div>
          <div class="cell-muted" style="margin-top:4px;">Solved</div>
        </div>
        <div class="right" role="cell">
          <div class="cell-strong">${p.penalty}</div>
          <div class="cell-muted" style="margin-top:4px;">Penalty</div>
        </div>
      `;
      elList.appendChild(row);
    });
  };

  const escapeHTML = (str) => {
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  };

  const renderAll = () => {
    // skeleton display
    elSkeleton.style.display = "grid";
    elList.style.display = "none";
    elEmpty.hidden = true;

    makeSkeleton(10);

    // Simulate loading
    setTimeout(() => {
      const data = getFiltered();
      renderPodium(data);
      renderRows(data);

      elSkeleton.style.display = "none";
      elList.style.display = "grid";
    }, 450);
  };

  // Init
  fillCollegeDropdown();
  renderAll();

  // Interactions
  const onChange = () => renderAll();

  elSearch.addEventListener("input", debounce(onChange, 120));
  elCollege.addEventListener("change", onChange);
  elSort.addEventListener("change", onChange);

  elReset.addEventListener("click", () => {
    elSearch.value = "";
    elCollege.value = "all";
    elSort.value = "score_desc";
    renderAll();
  });

  function debounce(fn, delay) {
    let t = null;
    return (...args) => {
      if (t) clearTimeout(t);
      t = setTimeout(() => fn.apply(null, args), delay);
    };
  }
})();