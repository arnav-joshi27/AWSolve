(() => {
  "use strict";

  // ----------------------------
  // Mobile navbar toggle
  // ----------------------------
  const navToggle = document.getElementById("navToggle");
  const navLinks = document.getElementById("navLinks");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
      navToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
    });

    // Close menu on link click (mobile)
    navLinks.querySelectorAll("a").forEach((a) => {
      a.addEventListener("click", () => {
        if (navLinks.classList.contains("open")) {
          navLinks.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
          navToggle.setAttribute("aria-label", "Open menu");
        }
      });
    });

    // Close on Escape
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && navLinks.classList.contains("open")) {
        navLinks.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
        navToggle.setAttribute("aria-label", "Open menu");
      }
    });
  }

  // ----------------------------
  // Smooth scroll for anchor links
  // ----------------------------
  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener("click", (e) => {
      const href = link.getAttribute("href");
      if (!href || href === "#") return;
      const target = document.querySelector(href);
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  // ----------------------------
  // Back-to-top button show/hide
  // ----------------------------
  const backTop = document.getElementById("backTop");
  if (backTop) {
    const toggleBackTop = () => {
      const show = window.scrollY > 600;
      backTop.classList.toggle("show", show);
    };
    window.addEventListener("scroll", toggleBackTop, { passive: true });
    toggleBackTop();

    backTop.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // ----------------------------
  // Scroll reveal animations (IntersectionObserver)
  // ----------------------------
  const revealEls = Array.from(document.querySelectorAll(".reveal"));
  if (revealEls.length) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );

    revealEls.forEach((el) => io.observe(el));
  }

  // ----------------------------
  // FAQ accordion open/close
  // ----------------------------
  const faqButtons = document.querySelectorAll(".faq-q");
  if (faqButtons.length) {
    faqButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const expanded = btn.getAttribute("aria-expanded") === "true";
        const panel = btn.nextElementSibling;
        const icon = btn.querySelector(".faq-icon");

        // Close others for clean UX (optional)
        faqButtons.forEach((other) => {
          if (other !== btn) {
            other.setAttribute("aria-expanded", "false");
            const p = other.nextElementSibling;
            if (p) p.hidden = true;
            const i = other.querySelector(".faq-icon");
            if (i) i.textContent = "+";
          }
        });

        btn.setAttribute("aria-expanded", String(!expanded));
        if (panel) panel.hidden = expanded;
        if (icon) icon.textContent = expanded ? "+" : "−";
      });
    });
  }

  // ----------------------------
  // Optional: Register modal (index page)
  // ----------------------------
  const modal = document.getElementById("registerModal");
  const openButtons = [
    "openRegisterTop",
    "openRegisterHero",
    "openRegisterCard",
    "openRegisterStrip",
    "openRegisterBottom",
  ].map((id) => document.getElementById(id)).filter(Boolean);

  const openModal = () => {
    if (!modal) return;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");

    // Lock scroll
    document.documentElement.style.overflow = "hidden";
    document.body.style.overflow = "hidden";

    // Focus first input
    const firstInput = modal.querySelector("input");
    if (firstInput) firstInput.focus();
  };

  const closeModal = () => {
    if (!modal) return;
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");

    // Unlock scroll
    document.documentElement.style.overflow = "";
    document.body.style.overflow = "";
  };

  openButtons.forEach((btn) => btn.addEventListener("click", openModal));

  if (modal) {
    modal.addEventListener("click", (e) => {
      const t = e.target;
      if (!(t instanceof HTMLElement)) return;
      if (t.dataset.close === "true") closeModal();
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal.classList.contains("open")) closeModal();
    });
  }

  // Simple front-end validation for modal form
  const form = document.getElementById("registerForm");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      let ok = true;

      const setHint = (name, msg) => {
        const input = form.querySelector(`[name="${name}"]`);
        if (!input) return;
        const hint = input.closest(".field")?.querySelector(".hint");
        if (hint) hint.textContent = msg || "";
        input.setAttribute("aria-invalid", msg ? "true" : "false");
      };

      const name = String(fd.get("name") || "").trim();
      const email = String(fd.get("email") || "").trim();
      const college = String(fd.get("college") || "").trim();
      const phone = String(fd.get("phone") || "").trim();
      const agree = fd.get("agree");

      setHint("name", "");
      setHint("email", "");
      setHint("college", "");
      setHint("phone", "");

      if (name.length < 2) { ok = false; setHint("name", "Please enter your full name."); }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { ok = false; setHint("email", "Please enter a valid email."); }
      if (college.length < 2) { ok = false; setHint("college", "Please enter your college."); }
      if (!/^\d{10}$/.test(phone.replace(/\D/g, ""))) { ok = false; setHint("phone", "Enter a 10-digit phone number."); }

      const agreeBox = form.querySelector('input[name="agree"]');
      if (agreeBox) agreeBox.setAttribute("aria-invalid", agree ? "false" : "true");
      if (!agree) ok = false;

      if (!ok) return;

      // Simulated submit
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        const original = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = "Submitted ✓";
        setTimeout(() => {
          submitBtn.disabled = false;
          submitBtn.textContent = original?.trim() || "Submit";
          form.reset();
          closeModal();
          // Nice confirmation toast-like alert (simple)
          alert("Registration submitted (simulated).");
        }, 800);
      }
    });
  }

  // Contest page: Dummy "Download Rulebook"
  const downloadRulebook = document.getElementById("downloadRulebook");
  const downloadRulebookBottom = document.getElementById("downloadRulebookBottom");
  [downloadRulebook, downloadRulebookBottom].filter(Boolean).forEach((btn) => {
    btn.addEventListener("click", () => {
      // Create a small dummy text file and trigger download
      const content =
        "AWSolve Rulebook (Dummy)\n\nThis file is a placeholder for the design evaluation.\n\nEvent: AWSolve\nDate: 12/03/2026\nTime: 9:00 AM\nVenue: Kamaraj Auditorium, AB3\nPrize Pool: ₹1,00,000\n\nNote: This is not a real event. All details are for design and evaluation purposes only.\n";
      const blob = new Blob([content], { type: "text/plain" });
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "AWSolve_Rulebook_Dummy.txt";
      document.body.appendChild(a);
      a.click();
      a.remove();

      URL.revokeObjectURL(url);
    });
  });

  // ----------------------------
  // Lightweight Canvas starfield
  // ----------------------------
  const canvas = document.getElementById("starfield");
  if (canvas instanceof HTMLCanvasElement) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = 0, h = 0;
    const DPR = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.floor(w * DPR);
      canvas.height = Math.floor(h * DPR);
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    };

    resize();
    window.addEventListener("resize", resize, { passive: true });

    const rand = (min, max) => Math.random() * (max - min) + min;

    const stars = Array.from({ length: Math.floor((w * h) / 18000) + 80 }, () => ({
      x: rand(0, w),
      y: rand(0, h),
      r: rand(0.4, 1.2),
      a: rand(0.10, 0.40),
      vx: rand(-0.06, 0.06),
      vy: rand(0.04, 0.12),
      tw: rand(0.002, 0.008),
      t: rand(0, 9999),
    }));

    const draw = () => {
      ctx.clearRect(0, 0, w, h);

      // subtle vignette
      const g = ctx.createRadialGradient(w * 0.5, h * 0.35, 20, w * 0.5, h * 0.35, Math.max(w, h) * 0.7);
      g.addColorStop(0, "rgba(255,255,255,0.04)");
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);

      for (const s of stars) {
        s.t += 1;
        const twinkle = (Math.sin(s.t * s.tw) + 1) * 0.5; // 0..1
        const alpha = s.a * (0.65 + 0.55 * twinkle);

        ctx.beginPath();
        ctx.fillStyle = `rgba(255,255,255,${alpha.toFixed(3)})`;
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();

        s.x += s.vx;
        s.y += s.vy;

        if (s.y > h + 10) { s.y = -10; s.x = rand(0, w); }
        if (s.x < -10) s.x = w + 10;
        if (s.x > w + 10) s.x = -10;
      }

      requestAnimationFrame(draw);
    };

    requestAnimationFrame(draw);
  }
})();
